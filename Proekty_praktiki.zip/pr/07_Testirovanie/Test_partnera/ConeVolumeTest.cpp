// Тест для функции coneVolume из проекта напарника (структура GeometryVolumes), принцип AAA
// Вставьте в файл unittest.cpp проекта напарника, подключив его GeometryVolumes.cpp
TEST_METHOD(ConeVolume_Radius3Height4_Returns12Pi)
{
    // Arrange
    double radius = 3;
    double height = 4;
    double expected = 12 * GeometryVolumes::PI;

    // Act
    double actual = GeometryVolumes::coneVolume(radius, height);

    // Assert
    Assert::AreEqual(expected, actual, 0.0001);
}
