using Microsoft.Win32;

namespace RegistrySettings;

// 4. Работа с реестром Windows: TextBox, кнопки «Сохранить настройки» и «Выбрать цвет», ColorDialog
public class Form1 : Form
{
    private const string KeyPath = @"Software\RegistrySettingsApp";

    private readonly TextBox textBox = new() { Left = 20, Top = 20, Width = 250 };
    private readonly Button saveButton = new() { Left = 20, Top = 60, Width = 160, Text = "Сохранить настройки" };
    private readonly Button colorButton = new() { Left = 190, Top = 60, Width = 120, Text = "Выбрать цвет" };
    private readonly ColorDialog colorDialog = new();

    public Form1()
    {
        Text = "Настройки в реестре";
        ClientSize = new Size(340, 110);
        Controls.AddRange(new Control[] { textBox, saveButton, colorButton });

        colorButton.Click += (s, e) =>
        {
            if (colorDialog.ShowDialog() == DialogResult.OK)
            {
                BackColor = colorDialog.Color;
            }
        };
        saveButton.Click += (s, e) => SaveSettings();
        Load += (s, e) => LoadSettings();
    }

    private void SaveSettings()
    {
        using RegistryKey key = Registry.CurrentUser.CreateSubKey(KeyPath);
        key.SetValue("Text", textBox.Text);
        key.SetValue("BackColor", BackColor.ToArgb());
    }

    private void LoadSettings()
    {
        using RegistryKey? key = Registry.CurrentUser.OpenSubKey(KeyPath);
        if (key == null) return;
        textBox.Text = key.GetValue("Text", "")?.ToString() ?? "";
        if (key.GetValue("BackColor") is int argb)
        {
            BackColor = Color.FromArgb(argb);
        }
    }
}
