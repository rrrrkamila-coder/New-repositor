# Проекты учебной практики

- `02_Otladka` — отладка и измерение времени (C++)
- `03_Kachestvo_koda` — самодокументируемый код (C++)
- `04_WindowsForms_Reestr` — Windows Forms и реестр (C#)
- `07_Testirovanie` — PowerRootOperations и модульные тесты (C++)
